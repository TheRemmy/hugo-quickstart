---
# preview details
title: Boarding Pass Wedding Invitation
category: Branding
category_slug: branding
image: images/project-2.jpeg
short: Nullam malesuada erat ut turpis.

# full details
full_image: images/project-2.jpeg
preview_link: https://bslthemes.com
info:
  - label: Project Description
    value: Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna.

  - label: Client
    value: Envato

  - label: Year
    value: 2021

  - label: Website
    value: bslthemes.com

images:
  - label: "Aliquam tincidunt mauris eu risus."
    image: "images/project-1.jpeg"

  - label: "Nunc dignissim risus id metus."
    image: "images/project-5.jpeg"

description2:
  enable: true
  text: "<p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.</p>"

---

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.

Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Donec mi odio, faucibus at, scelerisque quis, convallis in, nisi. Curabitur ullamcorper ultricies nisi. Nam eget dui.

Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.